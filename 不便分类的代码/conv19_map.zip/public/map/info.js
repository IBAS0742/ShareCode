
let np = {
    "全国": "china",
    "上海市": "shanghai",
    "云南省": "yunnan",
    "内蒙古": "neimenggu",
    "北京市": "beijing",
    "吉林省": "jilin",
    "四川省": "sichuang",
    "宁夏": "ningxia",
    "安徽省": "anhui",
    "山东省": "shandong",
    "山西省": "shanxi",
    "广东省": "guangdong",
    "广西": "guangxi",
    "新疆": "xinjiang",
    "江西省": "jiangxi",
    "江苏省": "jiangsu",
    "河南省": "henan",
    "河北省": "hebei",
    "浙江省": "zhejiang",
    "海南省": "hainan",
    "湖北省": "hubei",
    "湖南省": "hunan",
    "甘肃省": "ganshu",
    "福建省": "fujian",
    "西藏": "xizang",
    "贵州省": "guizhou",
    "辽宁省": "liaoning",
    "重庆市": "chongqin",
    "陕西省": "shanxi",
    "青海省": "qinghai",
    "黑龙江省": "heilongjiang"
}

let mapCenterAndZoom = {
    "china": {
        "center": [
            115.79,
            29.16,
        ],
        "zoom": 4
    },
    "shanghai": {
        "center": [
            121.472644,
            31.231706
        ],
        "zoom": 7
    },
    "yunnan": {
        "center": [
            102.712251,
            25.040609
        ],
        "zoom": 7
    },
    "neimenggu": {
        "center": [
            111.670801,
            40.818311
        ],
        "zoom": 7
    },
    "beijing": {
        "center": [
            116.405285,
            39.904989
        ],
        "zoom": 7
    },
    "jilin": {
        "center": [
            125.3245,
            43.886841
        ],
        "zoom": 7
    },
    "sichuang": {
        "center": [
            104.065735,
            30.659462
        ],
        "zoom": 7
    },
    "ningxia": {
        "center": [
            106.278179,
            38.46637
        ],
        "zoom": 7
    },
    "anhui": {
        "center": [
            117.283042,
            31.86119
        ],
        "zoom": 7
    },
    "shandong": {
        "center": [
            117.000923,
            36.675807
        ],
        "zoom": 7
    },
    "shanxi": {
        "center": [
            108.948024,
            34.263161
        ],
        "zoom": 7
    },
    "guangdong": {
        "center": [
            113.280637,
            23.125178
        ],
        "zoom": 7
    },
    "guangxi": {
        "center": [
            108.320004,
            22.82402
        ],
        "zoom": 7
    },
    "xinjiang": {
        "center": [
            87.617733,
            43.792818
        ],
        "zoom": 7
    },
    "jiangxi": {
        "center": [
            115.892151,
            28.676493
        ],
        "zoom": 7
    },
    "jiangsu": {
        "center": [
            118.767413,
            32.041544
        ],
        "zoom": 7
    },
    "henan": {
        "center": [
            113.665412,
            34.757975
        ],
        "zoom": 7
    },
    "hebei": {
        "center": [
            114.502461,
            38.045474
        ],
        "zoom": 7
    },
    "zhejiang": {
        "center": [
            120.153576,
            30.287459
        ],
        "zoom": 7
    },
    "hainan": {
        "center": [
            110.33119,
            20.031971
        ],
        "zoom": 7
    },
    "hubei": {
        "center": [
            114.298572,
            30.584355
        ],
        "zoom": 7
    },
    "hunan": {
        "center": [
            112.982279,
            28.19409
        ],
        "zoom": 7
    },
    "ganshu": {
        "center": [
            103.823557,
            36.058039
        ],
        "zoom": 7
    },
    "fujian": {
        "center": [
            119.306239,
            26.075302
        ],
        "zoom": 7
    },
    "xizang": {
        "center": [
            91.132212,
            29.660361
        ],
        "zoom": 7
    },
    "guizhou": {
        "center": [
            106.713478,
            26.578343
        ],
        "zoom": 7
    },
    "liaoning": {
        "center": [
            123.429096,
            41.796767
        ],
        "zoom": 7
    },
    "chongqin": {
        "center": [
            106.504962,
            29.533155
        ],
        "zoom": 7
    },
    "qinghai": {
        "center": [
            101.778916,
            36.623178
        ],
        "zoom": 7
    },
    "heilongjiang": {
        "center": [
            126.642464,
            45.756967
        ],
        "zoom": 7
    }
};